#!/usr/bin/env bash

lon_min=-72.6485375
lon_max=-70.9244466
lat_min=41.7723114
lat_max=42.8654280

let delta_lon=$(( $(( $lon_max - $lon_min )) /30 ))
let delta_lat=$(( $(( $lat_max - $lat_min )) /30 ))

echo "delta_lon : $delta_lon"
echo "delta_lat : $delta_lat"

for (( i = 0; i < 30; ++i )); do

  blon_min=$(( $lon_min + $(( i * $delta_lon )) ))
  blon_max=$(( $lon_min + $(( ( i + 1 ) * $delta_lon )) ))

  for (( j = 0; j < 30; ++j )); do

    blat_min=$(( $lat_min + $(( j * $delta_lat )) ))
    blat_max=$(( $lat_min + $(( ( j + 1 ) * $delta_lat )) ))
    
    /cs/local/lib/pkg/osmctools-20200327/bin/osmconvert ../boston_sidewalks_OSM.osm -b=$blon_min,$blat_min,$blon_max,$blat_max -o=sample${i}_${j}_OSM.osm --complete-ways

  done
done
